//
//  RelateApp.swift
//  Relate
//
//  Created by Webster Avosa on 16/06/2022.
//

import SwiftUI

@main
struct RelateApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
